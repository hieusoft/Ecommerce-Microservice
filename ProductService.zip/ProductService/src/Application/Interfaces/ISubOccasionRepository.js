class ISubOccasionRepository {
    async createSubOccasion(subOccasion) {
        throw new Error('Method not implemented.');
    }
    async getSubOccasionById(id) {
        throw new Error('Method not implemented.');
    }
    async getAllSubOccasions() {
        throw new Error('Method not implemented.');
    }
    async updateSubOccasion(id, subOccasion) {
        throw new Error('Method not implemented.');
    }
    async deleteSubOccasion(id) {
        throw new Error('Method not implemented.');
    }
}
module.exports = ISubOccasionRepository;