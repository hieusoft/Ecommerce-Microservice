class IOccasionRepository {
    async getAllOccasions() {
        throw new Error('Method not implemented.');
    }
    async getOccasionById(id) {
        throw new Error('Method not implemented.');
    }
    async createOccasion(occasionData) {
        throw new Error('Method not implemented.');
    }
    async updateOccasion(id, occasionData) {
        throw new Error('Method not implemented.');
    }
    async deleteOccasion(id) {
        throw new Error('Method not implemented.');
    }   
}

module.exports = IOccasionRepository;