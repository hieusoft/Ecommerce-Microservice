class IBouquetRepository {
    async createBouquet(dto) {
        throw new Error("Method not implemented");
    }
    async getBouquetById(id) {
        throw new Error("Method not implemented");
    }
    // async getAllBouquets() {
    //     throw new Error("Method not implemented");
    // }
    async updateBouquet(id, dto) {
        throw new Error("Method not implemented");
    }
    async deleteBouquet(id) {
        throw new Error("Method not implemented");
    }
    async getAllBouquets(query) {
        throw new Error("Method not implemented");
    }
}

module.exports = IBouquetRepository;
