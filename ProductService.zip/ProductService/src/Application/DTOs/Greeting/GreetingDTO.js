class GreetingDTO {
  constructor({ text, subOccasionId }) {
    this.text = text;
    this.subOccasionId = subOccasionId;
  }
}

module.exports = GreetingDTO;
