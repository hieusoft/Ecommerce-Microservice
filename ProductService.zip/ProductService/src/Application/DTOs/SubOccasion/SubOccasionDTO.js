class SubOccasionDTO{
    constructor({name, description, occasionId }) {
        this.name = name;
        this.description = description;
        this.occasionId = occasionId;
    }
}
module.exports = SubOccasionDTO;