class OccasionDTO {
  constructor({name, description }) {
    this.name = name;
    this.description = description;
  }
}

module.exports = OccasionDTO;
