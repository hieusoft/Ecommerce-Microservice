class Greeting {
  constructor({ id, text, subOccasionId }) {
    this.id = id;
    this.text = text;
    this.subOccasionId = subOccasionId;
  }
}

module.exports = Greeting;
