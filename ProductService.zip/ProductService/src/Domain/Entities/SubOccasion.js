class SubOccasion {
    constructor({id, name, description, occasionId}) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.occasionId = occasionId;
    }
}   
module.exports = SubOccasion;